from svmutil import *
import numpy as np
import matplotlib.pyplot as plt
x1,y1 = np.random.multivariate_normal([1,1], np.identity(2), 1000).T
x2,y2 = np.random.multivariate_normal([-1,-1], np.identity(2)*3, 1000).T
x = [{1:x1[i],2:y1[i]} for i in range(1000)] + [{1:x2[i],2:y2[i]} for i in range(1000)]
y = [1 for i in range(1000)] + [-1 for i in range(1000)]
m = svm_train(y,x,'-g 1')

xInNP = np.array([[x1[i],y1[i]] for i in range(1000)] + [[x2[i],y2[i]] for i in range(1000)])
x_min, x_max = xInNP[:, 0].min() - 1, xInNP[:, 0].max() + 1
y_min, y_max = xInNP[:, 1].min() - 1, xInNP[:, 1].max() + 1
h = 0.02
xx, yy = np.meshgrid(np.arange(x_min, x_max, h),
                     np.arange(y_min, y_max, h))
predictX = np.c_[xx.ravel(),yy.ravel()]
pXforLib = [{1: px[0], 2: px[1]} for px in predictX]
fakeY = [1 for i in range(len(pXforLib))]
p_label, p_acc, p_val = svm_predict(fakeY,pXforLib,m)


# Plot the decision boundary. For that, we will assign a color to each
# point in the mesh [x_min, x_max]x[y_min, y_max].



# Put the result into a color plot
Z = np.array(p_label).reshape(xx.shape)
plt.contourf(xx, yy, Z, cmap=plt.cm.coolwarm, alpha=0.8)

# Plot also the training points
plt.scatter(xInNP[:, 0], xInNP[:, 1], c=y, cmap=plt.cm.coolwarm)
plt.xlabel('Sepal length')
plt.ylabel('Sepal width')
plt.xlim(xx.min(), xx.max())
plt.ylim(yy.min(), yy.max())
plt.xticks(())
plt.yticks(())
plt.title('svm')

plt.show()

